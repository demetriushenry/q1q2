package com.demetrius.q2

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.demetrius.q2.viewmodel.WeatherViewModel

class MainActivity : AppCompatActivity() {

    private lateinit var location: EditText
    private lateinit var search: Button
    private lateinit var result: TextView
    private lateinit var weatherViewModel: WeatherViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        location = findViewById(R.id.edt_location)
        search = findViewById(R.id.bt_search)
        result = findViewById(R.id.tv_result)

//        weatherViewModel = ViewModelProvider(this).get(WeatherViewModel::class.java)
//        weatherViewModel.weather.observe(this, Observer { response ->
//            // TODO: 27/10/2021
//        })
    }
}