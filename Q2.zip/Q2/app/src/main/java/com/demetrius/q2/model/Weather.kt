package com.demetrius.q2.model

import com.google.gson.annotations.SerializedName

data class Weather(
    @SerializedName("city")val city: String,
    @SerializedName("region") val region: String,
    @SerializedName("temperature") val temperature: String,
    @SerializedName("date_time") val dateTime: String
)