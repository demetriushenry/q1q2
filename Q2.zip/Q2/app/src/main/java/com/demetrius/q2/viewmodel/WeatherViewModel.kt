package com.demetrius.q2.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.demetrius.q2.model.WeatherApi
import com.demetrius.q2.network.RetrofitClient
import java.lang.IllegalArgumentException

class WeatherViewModel : ViewModel() {
    private val weatherService = RetrofitClient().getRetrofit().create(WeatherApi::class.java)
    val weather = weatherService.getWeather(1)
}

class WeatherViewModelFactory : ViewModelProvider.Factory {
    override fun <T : ViewModel?> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(WeatherViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return WeatherViewModel() as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}