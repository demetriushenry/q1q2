package com.demetrius.q2.model

import androidx.lifecycle.LiveData
import com.demetrius.q2.network.ApiResponse
import retrofit2.http.GET
import retrofit2.http.Path

interface WeatherApi {
    @GET("")
    fun getWeather(@Path("id") id: Int): LiveData<ApiResponse<Weather>>
}