package com.demetrius.q1

import android.app.Application
import com.demetrius.q1.database.ToDoRoomDatabase
import com.demetrius.q1.repository.ToDoRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob

class Q1Application : Application() {
    private val applicationScope = CoroutineScope(SupervisorJob())
    private val database by lazy { ToDoRoomDatabase.getDatabase(this, applicationScope) }
    val repository by lazy { ToDoRepository(database.toDoDao()) }
}