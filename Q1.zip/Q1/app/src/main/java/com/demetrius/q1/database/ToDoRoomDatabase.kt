package com.demetrius.q1.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.sqlite.db.SupportSQLiteDatabase
import com.demetrius.q1.model.ToDo
import com.demetrius.q1.model.ToDoDao
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import java.sql.Date
import java.util.*

@Database(entities = [ToDo::class], version = 1, exportSchema = false)
@TypeConverters(Converters::class)
abstract class ToDoRoomDatabase : RoomDatabase() {
    abstract fun toDoDao(): ToDoDao

    private class ToDoDatabaseCallback(private val scope: CoroutineScope) :
        RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                scope.launch {
                    val toDoDao = database.toDoDao()

                    toDoDao.deleteAllToDos()

                    var toDo = ToDo(
                        "Title test",
                        "Description test",
                        Date(Calendar.getInstance().time.time),
                        false
                    )
                    toDoDao.insert(toDo)

                    toDo = ToDo(
                        "Title test 2",
                        "Description test 2",
                        Date(Calendar.getInstance().time.time),
                        true
                    )
                    toDoDao.insert(toDo)
                }
            }
        }
    }

    companion object {
        @Volatile
        private var INSTANCE: ToDoRoomDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): ToDoRoomDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    ToDoRoomDatabase::class.java,
                    "todo_database"
                )
                    .addCallback(ToDoDatabaseCallback(scope))
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}