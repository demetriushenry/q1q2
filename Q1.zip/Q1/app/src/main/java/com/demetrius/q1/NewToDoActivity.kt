package com.demetrius.q1

import android.app.Activity
import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.text.TextUtils
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import com.demetrius.q1.model.ToDo
import java.sql.Date
import java.text.SimpleDateFormat
import java.util.*

class NewToDoActivity : AppCompatActivity() {

    private lateinit var newTitle: EditText
    private lateinit var newDescription: EditText
    private lateinit var newCreatedDate: EditText
    private lateinit var newDone: CheckBox
    private lateinit var newTodo: Button

    private var calendar = Calendar.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_new_to_do)

        newTitle = findViewById(R.id.new_title)
        newDescription = findViewById(R.id.new_description)
        newCreatedDate = findViewById(R.id.new_created_date)
        newDone = findViewById(R.id.new_done)
        newTodo = findViewById(R.id.new_todo)

        val dateListener = DatePickerDialog.OnDateSetListener { _, p1, p2, p3 ->
            calendar.set(Calendar.YEAR, p1)
            calendar.set(Calendar.MONTH, p2)
            calendar.set(Calendar.DAY_OF_MONTH, p3)
            updateCreatedDate()
        }

        newCreatedDate.setOnClickListener {
            DatePickerDialog(
                this@NewToDoActivity,
                dateListener,
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
            ).show()
        }

        newTodo.setOnClickListener {
            val resultIntent = Intent()

            if (TextUtils.isEmpty(newTitle.text)) {
                setResult(Activity.RESULT_CANCELED, resultIntent)
            } else {
                val createdDate = java.util.Date(newCreatedDate.text.toString())
                val toDo = ToDo(
                    newTitle.text.toString(),
                    newDescription.text.toString(),
                    Date(createdDate.time),
                    newDone.isChecked
                )
                resultIntent.putExtra(EXTRA_REPLY, toDo)
                setResult(Activity.RESULT_OK, resultIntent)
            }
            finish()
        }
    }

    private fun updateCreatedDate() {
        val dateFormat = "MM/dd/yyyy"
        val sdf = SimpleDateFormat(dateFormat, Locale.US)
        val strDate = sdf.format(calendar.time)
        newCreatedDate.setText(strDate)
    }

    companion object {
        const val EXTRA_REPLY = "com.demetrius.q1.REPLY"
    }

}