package com.demetrius.q1.viewmodel

import androidx.lifecycle.*
import com.demetrius.q1.model.ToDo
import com.demetrius.q1.repository.ToDoRepository
import kotlinx.coroutines.launch
import java.lang.IllegalArgumentException

class ToDoViewModel(private val repository: ToDoRepository) : ViewModel() {
    val allToDos: LiveData<List<ToDo>> = repository.allToDos.asLiveData()

    fun insertToDo(toDo: ToDo) = viewModelScope.launch {
        repository.insertToDo(toDo)
    }

    fun updateToDo(toDo: ToDo) = viewModelScope.launch {
        repository.updateToDo(toDo)
    }

    fun deleteToDo(toDo: ToDo) = viewModelScope.launch {
        repository.deleteToDo(toDo)
    }
}

class ToDoViewModelFactory(private val repository: ToDoRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel?> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(ToDoViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return ToDoViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }

}