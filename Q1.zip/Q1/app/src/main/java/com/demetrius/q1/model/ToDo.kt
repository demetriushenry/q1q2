package com.demetrius.q1.model

import android.os.Parcelable
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.parcelize.Parcelize
import java.sql.Date

@Entity(tableName = "todo")
@Parcelize
data class ToDo(
    @PrimaryKey @ColumnInfo(name = "title") val title: String,
    val description: String?,
    val createdDate: Date,
    var done: Boolean = false
) : Parcelable
