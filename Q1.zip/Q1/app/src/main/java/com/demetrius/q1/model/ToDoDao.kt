package com.demetrius.q1.model

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ToDoDao {
    @Query("SELECT * FROM todo ORDER BY title ASC")
    fun getAllToDos(): Flow<List<ToDo>>

    @Query("SELECT * FROM todo WHERE title = :title ORDER BY title ASC")
    fun getAllToDosByTitle(title: String): Flow<List<ToDo>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertToDos(vararg toDos: ToDo)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(toDo: ToDo)

    @Delete
    suspend fun deleteToDos(vararg toDos: ToDo)

    @Delete
    suspend fun delete(toDo: ToDo)

    @Query("DELETE FROM todo")
    suspend fun deleteAllToDos()

    @Update
    suspend fun updateToDos(vararg toDos: ToDo)

    @Update
    suspend fun update(toDo: ToDo)
}