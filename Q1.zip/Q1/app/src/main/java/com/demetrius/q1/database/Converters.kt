package com.demetrius.q1.database

import androidx.room.TypeConverter
import java.sql.Date

class Converters {
    @TypeConverter
    fun fromTimeStamp(value: Long?) : Date {
        return Date(value ?: 0)
    }

    @TypeConverter
    fun dateToTimestamp(date: Date?) : Long {
        return date?.time ?: 0
    }
}