package com.demetrius.q1.repository

import androidx.annotation.WorkerThread
import com.demetrius.q1.model.ToDo
import com.demetrius.q1.model.ToDoDao
import kotlinx.coroutines.flow.Flow

class ToDoRepository(private val toDoDao: ToDoDao) {
    val allToDos: Flow<List<ToDo>> = toDoDao.getAllToDos()

    @WorkerThread
    suspend fun insertToDo(toDo: ToDo) {
        toDoDao.insert(toDo)
    }

    @WorkerThread
    suspend fun updateToDo(toDo: ToDo) {
        toDoDao.update(toDo)
    }

    @WorkerThread
    suspend fun deleteToDo(toDo: ToDo) {
        toDoDao.delete(toDo)
    }
}