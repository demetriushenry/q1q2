package com.demetrius.q1.view

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.demetrius.q1.NewToDoActivity
import com.demetrius.q1.Q1Application
import com.demetrius.q1.R
import com.demetrius.q1.model.ToDo
import com.demetrius.q1.viewmodel.ToDoViewModel
import com.demetrius.q1.viewmodel.ToDoViewModelFactory
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : AppCompatActivity(), ToDoListAdapter.OnLayoutClickListener {

    private val toDoViewModel: ToDoViewModel by viewModels {
        ToDoViewModelFactory((application as Q1Application).repository)
    }
    private val resultLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val data: Intent? = result.data
                data?.getParcelableExtra<ToDo>(NewToDoActivity.EXTRA_REPLY)?.let { toDo ->
                    toDoViewModel.insertToDo(toDo)
                }
            } else {
                Toast.makeText(
                    applicationContext,
                    R.string.todo_item_not_saved,
                    Toast.LENGTH_LONG
                ).show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerview)
        val adapter = ToDoListAdapter(this)
        recyclerView.adapter = adapter
        recyclerView.layoutManager = LinearLayoutManager(this)

        val fab = findViewById<FloatingActionButton>(R.id.fab)
        fab.setOnClickListener {
            val intent = Intent(this@MainActivity, NewToDoActivity::class.java)
            resultLauncher.launch(intent)
        }

        toDoViewModel.allToDos.observe(this) { toDos ->
            toDos?.let { adapter.submitList(it) }
        }
    }

    override fun onLayoutItemClicked(toDo: ToDo) {
        toDoViewModel.updateToDo(toDo)
        Log.i("TODO", "Updated")
    }

    override fun onLayoutItemLongClicked(toDo: ToDo) {
        toDoViewModel.deleteToDo(toDo)
        Log.i("TODO", "Deleted")
    }
}