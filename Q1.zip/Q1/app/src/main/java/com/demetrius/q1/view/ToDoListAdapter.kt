package com.demetrius.q1.view

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.demetrius.q1.R
import com.demetrius.q1.model.ToDo

class ToDoListAdapter(private val listener: OnLayoutClickListener) :
    ListAdapter<ToDo, ToDoListAdapter.ToDoViewHolder>(ToDosComparator()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ToDoViewHolder {
        return ToDoViewHolder.create(parent)
    }

    override fun onBindViewHolder(holder: ToDoViewHolder, position: Int) {
        val item = getItem(position)
        holder.bind(item, listener)
    }

    class ToDoViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val card: CardView = itemView.findViewById(R.id.card_item)
        private val title: TextView = itemView.findViewById(R.id.tv_title)
        private val description: TextView = itemView.findViewById(R.id.tv_description)
        private val createdDate: TextView = itemView.findViewById(R.id.tv_created_date)
        private val done: CheckBox = itemView.findViewById(R.id.cb_done)
        private val deleteButton: Button = itemView.findViewById(R.id.bt_delete)
        private lateinit var listener: OnLayoutClickListener
        private lateinit var itemToDo: ToDo

        fun bind(toDo: ToDo, listener: OnLayoutClickListener) {
            title.text = toDo.title
            description.text = toDo.description
            createdDate.text = toDo.createdDate.toString()
            done.isChecked = toDo.done
            this.listener = listener
            itemToDo = toDo

            card.setOnClickListener {
                Log.i("Clicked", "card has been clicked")
                itemToDo.done = !itemToDo.done
                listener.onLayoutItemClicked(itemToDo)
            }

            card.setOnLongClickListener {
                Log.i("Long Clicked", "card has been pressed for a long time")
                deleteButton.visibility = View.VISIBLE
                true
            }

            deleteButton.setOnClickListener {
                Log.i("Delete Clicked", "delete has been pressed")
                listener.onLayoutItemLongClicked(itemToDo)
            }
        }

        companion object {
            fun create(parent: ViewGroup): ToDoViewHolder {
                val view: View =
                    LayoutInflater.from(parent.context).inflate(R.layout.list_todos, parent, false)
                return ToDoViewHolder(view)
            }
        }
    }

    class ToDosComparator : DiffUtil.ItemCallback<ToDo>() {
        override fun areItemsTheSame(oldItem: ToDo, newItem: ToDo): Boolean {
            return oldItem === newItem
        }

        override fun areContentsTheSame(oldItem: ToDo, newItem: ToDo): Boolean {
            return oldItem.title == newItem.title
        }

    }

    interface OnLayoutClickListener {
        fun onLayoutItemClicked(toDo: ToDo)
        fun onLayoutItemLongClicked(toDo: ToDo)
    }
}